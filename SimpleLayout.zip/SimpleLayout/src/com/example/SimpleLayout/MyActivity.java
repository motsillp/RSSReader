package com.example.SimpleLayout;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.example.SimpleLayout.R;

public class MyActivity extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        LinearLayout oll = (LinearLayout) findViewById(R.id.BigLinearLayout);

        for (int i = 0; i<25; i++)
        {
            LinearLayout ll = new LinearLayout(this);
            ll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            ll.setOrientation(LinearLayout.HORIZONTAL);
            oll.addView(ll);

            ImageView iv = new ImageView(this);
            iv.setImageResource(R.drawable.ic_launcher);
            ll.addView(iv);
            LinearLayout ll2 = new LinearLayout(this);
            ll2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            ll2.setOrientation(LinearLayout.VERTICAL);
            ll.addView(ll2);
            TextView tv = new TextView(this);
            tv.setText("TESTING TITLE");
            ll2.addView(tv);
            TextView tvv = new TextView(this);
            tvv.setText("TESTING DESCRIPTION: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed efficitur libero ac ex molestie, sed ullamcorper metu...");
            ll2.addView(tvv);
        }


    }
}
