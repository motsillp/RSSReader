package com.example.SimpleLayout;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

/**
 * Created by motsilp69312 on 2017/05/22.
 */
public class custom_feed extends Activity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.custom_feed_menu, menu);
        ActionBar actionBar = getActionBar();
        actionBar.setDisplayShowTitleEnabled(true);
        actionBar.show();
        return true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_feed);
    }

    public void create_feed()
    {
        ContentValues params = new ContentValues();
        EditText nameEdit = (EditText) findViewById(R.id.nameEdit) ;
        EditText urlEdit = (EditText) findViewById(R.id.urlEdit) ;
        String name = nameEdit.getText().toString();
        String url = urlEdit.getText().toString();
        params.put("name",name);
        params.put("url",url);
        AsyncHTTPRequest AsyncLogin = new AsyncHTTPRequest(
                "http://lamp.ms.wits.ac.za/~s1312548/add_feed.php",params) {
            @Override
            protected void onPostExecute(String output) {
                finish();

            }
        };
        AsyncLogin.execute();
    }

    public void CreateFeed(View view) {
        create_feed();
    }

    public void get_help(MenuItem item) {
        String url = "http://lamp.ms.wits.ac.za/~s1312548/help.html";
        Intent myIntent = new Intent(this, WebStuuf.class);
        myIntent.putExtra("key", url);
        this.startActivity(myIntent);
    }
}