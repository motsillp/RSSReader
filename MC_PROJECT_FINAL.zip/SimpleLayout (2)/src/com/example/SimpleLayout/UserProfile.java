package com.example.SimpleLayout;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.*;

/**
 * Created by motsilp69312 on 2017/05/21.
 */
public class UserProfile extends Activity {
    String message,curr_email,curr_pass,email,password;
    Button update;
    EditText newEmail, newPass1, newPass2, currPass;
    CheckBox newEmailCheck, newPassCheck;
    public void onCreate(Bundle savedInstanceState) {
        message = "";
        curr_pass = getIntent().getStringExtra("CurrPass");
        curr_email = getIntent().getStringExtra("CurrEmail");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.userprofile);
        Context me = this;

        update = (Button)findViewById(R.id.updateUserButton);
        update.setEnabled(false);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProgressDialog update = new ProgressDialog(UserProfile.this);
                update.setTitle("User profile changes");
                update.setMessage("Please wait as we update your credentials");
                update.show();
                ContentValues params = new ContentValues();
                params.put("old_email",curr_email);
                params.put("new_email",email);
                params.put("old_password",curr_pass);
                params.put("new_password",password);

                AsyncHTTPRequest AsyncChange = new AsyncHTTPRequest(
                        "http://lamp.ms.wits.ac.za/~s1312548/update_user.php",params) {
                    @Override
                    protected void onPostExecute(String output) {
                        Intent intent = new Intent();
                        intent.putExtra("new_pass",newPass1.getText().toString());
                        intent.putExtra("new_email",newEmail.getText().toString());
                        update.hide();
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                };
                AsyncChange.execute();
            }
        });

        newEmail = (EditText)findViewById(R.id.newEmailEdit);
        newEmail.setEnabled(false);

        newPass1 = (EditText)findViewById(R.id.newPass1Edit);
        newPass1.setEnabled(false);

        newPass2 = (EditText)findViewById(R.id.newPass2Edit);
        newPass2.setEnabled(false);

        currPass = (EditText)findViewById(R.id.currPasswordEdit);
        currPass.setEnabled(false);

        newEmailCheck = (CheckBox)findViewById(R.id.emailCheck);
        newEmailCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    newEmail.setEnabled(true);
                    EnableChange();
                }else{
                    newEmail.setEnabled(false);
                    EnableChange();
                }
            }
        });

        newPassCheck = (CheckBox)findViewById(R.id.changePassword);
        newPassCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    currPass.setEnabled(true);
                    newPass1.setEnabled(true);
                    newPass2.setEnabled(true);
                   // EnableUpdate();
                    EnableChange();
                }else{
                    currPass.setEnabled(false);
                    newPass1.setEnabled(false);
                    newPass2.setEnabled(false);
                   // EnableUpdate();
                    EnableChange();
                }
            }
        });

        newEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
            //    EnableUpdate();
                EnableChange();
            }
        });

        newPass1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
            //    EnableUpdate();
                EnableChange();
            }
        });

        newPass2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
             //   EnableUpdate();
                EnableChange();
            }
        });

        currPass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
             //   EnableUpdate();
                EnableChange();
            }
        });
    }

    public boolean isEmailReady(){
        if(newEmailCheck.isChecked()){
            if(newEmail.getText().toString().equals("")){
                return false;
            }else{
                return true;
            }
        }else{
            return false;
        }
    }

    public boolean isPasswordReady(){
        if(newPassCheck.isChecked()){
            if(currPass.getText().toString().equals(curr_pass)){
                if(newPass1.getText().toString().equals(newPass2.getText().toString()) && !newPass1.getText().toString().equals("")){
                   return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

    public void EnableChange(){
        if(isPasswordReady() && isEmailReady()){
            update.setEnabled(true);
            password = newPass1.getText().toString();
            email = newEmail.getText().toString();
        }else if (isPasswordReady()){
            if(!newEmailCheck.isChecked()){
                update.setEnabled(true);
                password = newPass1.getText().toString();
                email = curr_email;
            }else{
                update.setEnabled(false);
            }
        }else if(isEmailReady()){
            if(!newPassCheck.isChecked()){
                update.setEnabled(true);
                password = curr_pass;
                email = newEmail.getText().toString();
            }else{
                update.setEnabled(false);
            }
        }else{
            update.setEnabled(false);
        }
    }

}
