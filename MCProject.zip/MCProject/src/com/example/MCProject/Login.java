package com.example.MCProject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Login extends Activity {
    /**
     * Called when the activity is first created.
     */
    TextView register;
    Button login;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        Context me = this;
        register = (TextView)findViewById(R.id.registerText);
        login = (Button)findViewById(R.id.loginButton);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goRegister = new Intent(me, Register.class);
                startActivity(goRegister);
                //Log.d("INTENT", "switching over...")
            }
        });
    }


}
