package com.example.MCProject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Created by 1312548 on 2017/05/17.
 */
public class AddTags extends Activity {
    Button save;
    CheckBox myTagBox, newTagBox;
    LinearLayout myTagsLL, newTagsLL;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addtags);
        Context me = this;
        save = (Button)findViewById(R.id.saveChangesButton);
        myTagsLL = (LinearLayout)findViewById(R.id.myTagsLinLayout);
        newTagsLL = (LinearLayout)findViewById(R.id.newTagsLinLayout);
        //This is just to test if it add checkboxes
        for(int i = 0; i < 10;i++){
            myTagBox = new CheckBox(AddTags.this);
            myTagBox.setText("CheckBox "+Integer.toString(i));
            myTagBox.setChecked(true);
            myTagsLL.addView(myTagBox);
            newTagBox = new CheckBox(AddTags.this);
            newTagBox.setText("CheckBox "+Integer.toString(i));
            newTagBox.setChecked(false);
            newTagsLL.addView(newTagBox);
        };

    }
}
