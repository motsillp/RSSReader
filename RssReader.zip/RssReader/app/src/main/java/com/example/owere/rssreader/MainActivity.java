package com.example.owere.rssreader;

import android.app.Activity;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {


    ArrayList<String> list = new ArrayList<String>();
    ArrayAdapter<String> adapter;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        lv = (ListView) findViewById(R.id.stuuf);
        lv.setAdapter(adapter);
        parseRSS("test");
    }

    void parseRSS(String RSS)
    {
        String title = "";
        String link = "";
        String description = "";

        try
        {
            XmlPullParserFactory xmlFactoryObject = XmlPullParserFactory.newInstance();
            XmlPullParser parser = xmlFactoryObject.newPullParser();
            InputStream feed = getResources().openRawResource(getResources().getIdentifier(RSS, "raw", getPackageName()));;

            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(feed, null);

            int event;
            String text = "";

            try
            {
                event = parser.getEventType();
                while (event != XmlPullParser.END_DOCUMENT) {
                    String name=parser.getName();

                    switch (event)
                    {
                        case XmlPullParser.START_TAG:
                            break;

                        case XmlPullParser.TEXT:
                            text = parser.getText();
                            break;

                        case XmlPullParser.END_TAG:
                            switch (name) {
                                case "title":
                                    title = text;
                                    list.add(title);
                                    break;
                                case "link":
                                    link = text;
                                    //list.add(link);
                                    break;
                                case "description":
                                    description = text;
                                    //list.add(description);
                                    break;
                            }
                    }

                    adapter.notifyDataSetChanged();
                    event = parser.next();
                }
            }catch (Exception e)
                {

                }

        } catch (Exception e)
        {

        }

    }
}
